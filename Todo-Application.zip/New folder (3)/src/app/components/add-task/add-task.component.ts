import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { TodosService } from 'src/app/services/todos.service';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router,
    private todoService: TodosService) { }

  ngOnInit() {
    this.addForm = this.formBuilder.group({
      id: [],
      taskName: ['',Validators.required],
      taskStatus:['',Validators.required]

    });
  }
  onSubmit(){
    this.submitted = true;

    //If validation failed,it should return to validate again
    if(this.addForm.invalid){
      return;
    }
    console.log(this.addForm.value);
    this.todoService.createTodo(this.addForm.value).subscribe(data =>{
      alert(this.addForm.controls.taskName.value
        + ' record is added successfully..!');
        this.router.navigate(['list-todo']);
    })
  }
}
