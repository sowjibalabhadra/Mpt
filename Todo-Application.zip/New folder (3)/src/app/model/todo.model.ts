export class Todo{
    id:number;
    taskName: string;
    taskStatus:string;

}