import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product} from '../model/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http:HttpClient) { }
  baseUrl:string = "http://localhost:3000/Products";

  //Get All Products
  getProducts(){
    return this.http.get<Product[]>(this.baseUrl);
  }
  //Get Products By Id
  getProductsById(id:number){
    return this.http.get<Product>(this.baseUrl+"/"+id);
  }
  //Add Product
  createProduct(product: Product){
    return this.http.post(this.baseUrl,product);
  }
  //Modify Product
  updateProduct(product:Product){
    return this.http.put(this.baseUrl+'/'+product.id,product);
  }
  //Delete Products By Id
  deleteProduct(id:number){
    return this.http.delete(this.baseUrl+'/'+id);
  }
}

