import { Component, OnInit, ViewChild } from '@angular/core';
import { Product } from 'src/app/model/product.model';
import { Router } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';

@Component({
  selector: 'app-list-product',
  templateUrl: './list-product.component.html',
  styleUrls: ['./list-product.component.css']
})
export class ListProductComponent implements OnInit {

  //creating an Array of Product class
  products: Product[];
  searchText: any;
  product: any;
  
  
  @ViewChild(MatSort, {static: false}) sort: MatSort;
  
  displayedColumns: string[] = ['id', 'productName', 'productDescription','productPrice', 'action'];
  //constructor dependency Injection
  constructor(private router: Router, private productService: ProductService) { }
  applyFilter(filterValue: string) {
    this.product.filter = filterValue.trim().toLowerCase();
  }
  

  //Delete Product
  deleteProduct(product: Product): void {
    let result = confirm("Do you want to delete Product?");
    if (result) {
      this.productService.deleteProduct(product.id)
        .subscribe(data => {
          this.products = this.products.filter
            (t => t !== product);
        })
      alert(`${product.productName} record is deleted..!`);


    }
  }

  //Modify Task
  editProduct(product: Product): void {

    this.router.navigate(['edit-product', product.id.toString()]);
  }
  //Add New Task
  addProduct(): void {
    this.router.navigate(['add-product']);
  }

  //loading all users as soon as component gets loaded
  ngOnInit() {

  //   if (localStorage.getItem("username") != null) {
  //     this.productService.getProducts()
  //       .subscribe(data => {
  //         this.products = data;
  //       });
  //   }
  //   else {
  //     this.router.navigate(['/login']);
  //   }
  // }
  this.onSubmit(confirm);
}
onSubmit(confirm){
  this.productService.getProducts().subscribe(data => {
    this.products = data;
    this.product= new MatTableDataSource(this.products);
        this.product.sort = this.sort;
    console.log(this.products);
  });
}

}

