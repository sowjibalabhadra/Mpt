import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router,
    private productService: ProductService) { }

  ngOnInit() {
    this.addForm = this.formBuilder.group({
      id: [],
      productName: ['',Validators.required],
      productPrice: ['',Validators.required],
      productDescription: ['',Validators.required]
    });
  }
  onSubmit(){
    this.submitted = true;

    //If validation failed,it should return to validate again
    if(this.addForm.invalid){
      return;
    }
    console.log(this.addForm.value);
    this.productService.createProduct(this.addForm.value).subscribe(data =>{
      this.addForm.controls.productName.value;
      Swal.fire(
        'Good Job!',
        'Your details are added!',
        'success'
      )
      this.router.navigate(['list-product']);
    })
  }
}
