import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Product } from 'src/app/model/product.model';
import { Router, ActivatedRoute } from '@angular/router';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {

  editForm: FormGroup;
  submitted: boolean = false;
  product: Product;
  productId: string;
  constructor(private formBuilder: FormBuilder, private router: Router,
    private route: ActivatedRoute,
    private productService: ProductService) {
    this.route.params.subscribe(params => this.productId = params['id']);
    console.log(this.productId);
  }
  
  ngOnInit() {
    
    if (this.productId != null) {
      if (!this.productId) {
        alert('Invalid Action');
        this.router.navigate(['list-product']);
        return;
      }
      this.editForm = this.formBuilder.group({
        id: [],
        productName: ['',Validators.required],
        productPrice:['',Validators.required],
        productDescription: ['',Validators.required]
        
      });

      
      this.productService.getProductsById(+this.productId).subscribe(data => {
        this.editForm.setValue(data)
      });
    }
    else {
      this.router.navigate(['/login']);
    }
  }//end of ngOnInit() function

  onSubmit() {
    this.submitted = true;
    if (this.editForm.invalid) {
      return;
    }

    this.productService.updateProduct(this.editForm.value)
      //.pipe(first())
      .subscribe(data => {
        this.router.navigate(['list-product']);
      }, error => {
        alert(error);
      });

  }

}

